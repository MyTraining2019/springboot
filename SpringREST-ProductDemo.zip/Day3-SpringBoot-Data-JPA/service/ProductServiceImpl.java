package org.cap.demo.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Product;
import org.springframework.stereotype.Service;

@Service("prodService")
public class ProductServiceImpl implements IProductService{

	private static final AtomicInteger productId=new AtomicInteger(0);
	
	
	private static List<Product> products=dummyProductList();
	
	public static List<Product> dummyProductList(){
		List<Product> products=new ArrayList<>();
		products.add(new Product(productId.incrementAndGet(), "Lux", 45.67, 14));
		products.add(new Product(productId.incrementAndGet(), "Medimix", 46.67, 104));
		products.add(new Product(productId.incrementAndGet(), "Cintol", 89.67, 3));
		products.add(new Product(productId.incrementAndGet(), "Lifebouy", 90.67, 123));
		products.add(new Product(productId.incrementAndGet(), "liril", 45.67, 90));
		products.add(new Product(productId.incrementAndGet(), "Pears", 45.67, 100));
		products.add(new Product(productId.incrementAndGet(), "Detol", 45.67, 1));
		products.add(new Product(productId.incrementAndGet(), "Santoor", 45.67, 16));
		
		return products;
	}
	
	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}

	@Override
	public Product findProducts(int productId) {
		for(Product product:products)
		{
			if(product.getProductId()==productId) {
				return product;
			}
		}
		return null;
	}

	@Override
	public List<Product> deleteProducts(int productId) {
		boolean flag=false;
		Iterator<Product> iterator= products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				iterator.remove();
				flag=true;
				break;
			}
		}
		
		if(flag)
		return products;
		else
			
			return null;
	}

	@Override
	public List<Product> createProduct(Product product) {
		products.add(product);
		return products;
	}

	@Override
	public List<Product> updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
