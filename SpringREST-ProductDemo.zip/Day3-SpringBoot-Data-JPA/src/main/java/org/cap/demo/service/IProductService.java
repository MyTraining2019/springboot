package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Product;
import org.springframework.data.repository.query.Param;

public interface IProductService {
	
	public List<Product> getAllProducts();
	public Product findProducts(int productId);
	
	public List<Product> deleteProducts(int productId);
	
	public List<Product> createProduct(Product product);
	
	//public List<Product> updateProduct(Product product);
	
	public List<Product> findByProductIdAndQuantity(int productId,int qty);
	
	public List<Product> findByProductIdOrProductNameOrQuantity
	(int productId,String pName,int qty);
	
	
	public List<Product> findProductDetails(int qty);
	
	public List<Product> fetchAllProducts(int quantity,
			int prodId);

}
