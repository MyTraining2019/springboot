package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.pojo.Product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("productDao")
@Transactional
public interface IProductDao extends JpaRepository<Product, Integer>{
	
	
	public List<Product> findByProductIdAndQuantity(int productId,int qty);
	public List<Product> findByProductIdOrProductNameOrQuantity
			(int productId,String pName,int qty);
	
	//@Query("select prod from Product prod where prod.quantity>=50")
	@Query("select prod from Product prod where prod.quantity>=?")
	public List<Product> findProductDetails(int qty);
	
	
	@Query("select prod from Product prod where productId=:prodId or quantity=:qty")
	public List<Product> fetchAllProducts(@Param("qty")int quantity,
			@Param("prodId")int prodId);

}
