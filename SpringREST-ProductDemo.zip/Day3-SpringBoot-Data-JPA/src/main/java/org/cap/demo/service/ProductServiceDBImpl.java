package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IProductDao;
import org.cap.demo.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("prodService")
public class ProductServiceDBImpl implements IProductService {
	
	@Autowired
	private IProductDao productDao;

	@Override
	public List<Product> getAllProducts() {
		
		return productDao.findAll();
	}

	@Override
	public Product findProducts(int productId) {
		
		return productDao.findOne(productId);
	}

	@Override
	public List<Product> deleteProducts(int productId) {
		productDao.delete(productId);
		return productDao.findAll();
	}

	@Override
	public List<Product> createProduct(Product product) {
		productDao.save(product);
		return productDao.findAll();
	}

	@Override
	public List<Product> findByProductIdAndQuantity(int productId,int qty)
 {
		
		return productDao.findByProductIdAndQuantity(productId, qty);
	}

	@Override
	public List<Product> findByProductIdOrProductNameOrQuantity(int productId, String pName, int qty) {
		// TODO Auto-generated method stub
		return productDao.findByProductIdOrProductNameOrQuantity(productId, pName, qty);
	}

	@Override
	public List<Product> findProductDetails(int qty) {
		// TODO Auto-generated method stub
		return productDao.findProductDetails(qty);
	}

	@Override
	public List<Product> fetchAllProducts(int quantity, int prodId) {
		// TODO Auto-generated method stub
		return productDao.fetchAllProducts(quantity, prodId);
	}

	/*@Override
	public List<Product> updateProduct(Product product) {
		
		productDao.save(product);
		
		return productDao.findAll();
	}*/

}
