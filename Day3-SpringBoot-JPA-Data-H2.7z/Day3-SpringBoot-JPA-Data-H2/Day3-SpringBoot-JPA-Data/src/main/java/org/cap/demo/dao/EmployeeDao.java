package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.pojo.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("empDao")
@Transactional
public interface EmployeeDao extends JpaRepository<Employee, Integer> {

	public List<Employee> findByFirstName(String firstName);
	public List<Employee> findByFirstNameOrLastName(String firstName,
				String lastName);
	
	//JPQL Query
	//@Query("select emp from Employee emp where emp.salary > :empSalary and emp.firstName= :fName")
	//public List<Employee> filterBySalary(double empSalary, String fName);
	
	
	@Query("select emp from Employee emp where emp.salary > ?")
	public List<Employee> filterBySalary(double empSalary);
	
	//@Query(name="findById")
	//public List<Employee> findById();
	
	//@Query(name="sqlQuery")
	//public List<Employee> sqlQuery();
	
	
	@Query("select emp from Employee emp where emp.firstName LIKE %:searchTerm% order by salary")
	public List<Employee> searchFirstNameLikeKey(@Param("searchTerm")String searchTerm);
	
}
