package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Employee;
import org.springframework.data.repository.query.Param;

public interface EmployeeService {
	
	//CRUD Operation
	public List<Employee> getAllEmployee();
	public Employee findEmployee(int employeeId);
	
	public List<Employee> deleteEmployee(int employeeId);
	
	public List<Employee> createEmployee(Employee employee);
	
	public List<Employee> updateEmployee(Employee employee);
	
	
	
	//Other Query
	public List<Employee> findByFirstName(String firstName);
	public List<Employee> findByFirstNameOrLastName(String firstName,
			String lastName);
	
	public List<Employee> filterBySalary(double salary);
	
	public List<Employee> searchFirstNameLikeKey(String searchTerm);
}
