package org.cap.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Employee;
import org.springframework.stereotype.Service;


@Service("empService")
public class EmployeeServiceImpl implements EmployeeService {
	private static AtomicInteger empId=new AtomicInteger(0);
	private static List<Employee> employees;
	
	static {
		employees=dummyEmployeeList();
	}

	@Override
	public List<Employee> getEmployees() {
		
		return employees;
	}

	private static List<Employee> dummyEmployeeList() {
		
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(empId.getAndIncrement(), "Tom", "Jerry", 12000));
		employees.add(new Employee(empId.getAndIncrement(), "Jack", "Jercy", 20001));
		employees.add(new Employee(empId.getAndIncrement(), "Emi", "Jerry", 34000));
		employees.add(new Employee(empId.getAndIncrement(), "Kine", "Thomson", 78000));
		employees.add(new Employee(empId.getAndIncrement(), "larry", "Jack", 45000));
		employees.add(new Employee(empId.getAndIncrement(), "John", "Abraham", 33000));
		return employees;
	}

	@Override
	public Employee findEmployee(int employeeId) {
		
		for(Employee emp:employees) {
			if(emp.getEmpId() == employeeId)
				return emp;
		}
		
		return null;
	}

}
