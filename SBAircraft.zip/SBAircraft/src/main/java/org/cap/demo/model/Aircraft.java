package org.cap.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value= 
{"hibernateLazyInitializer","handler","created"})
public class Aircraft {
	
	@Id
	@GeneratedValue
	private int aircraftId;
	private String aircraftName;
	private double crusingRange;
	
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date launchDate;
	public int getAircraftId() {
		return aircraftId;
	}
	public void setAircraftId(int aircraftId) {
		this.aircraftId = aircraftId;
	}
	public String getAircraftName() {
		return aircraftName;
	}
	public void setAircraftName(String aircraftName) {
		this.aircraftName = aircraftName;
	}
	public double getCrusingRange() {
		return crusingRange;
	}
	public void setCrusingRange(double crusingRange) {
		this.crusingRange = crusingRange;
	}
	public Date getLaunchDate() {
		return launchDate;
	}
	public void setLaunchDate(Date launchDate) {
		this.launchDate = launchDate;
	}
	public Aircraft(int aircraftId, String aircraftName, double crusingRange, Date launchDate) {
		super();
		this.aircraftId = aircraftId;
		this.aircraftName = aircraftName;
		this.crusingRange = crusingRange;
		this.launchDate = launchDate;
	}
	public Aircraft() {
		
	}
	@Override
	public String toString() {
		return "Aircraft [aircraftId=" + aircraftId + ", aircraftName=" + aircraftName + ", crusingRange="
				+ crusingRange + ", launchDate=" + launchDate + "]";
	}
	

}
