package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Aircraft;
import org.springframework.data.repository.query.Param;

public interface IAircraftService {
	public List<Aircraft> addAll();
	
	public List<Aircraft> getAllAircrafts();

	public Aircraft findAircraft(int aircraftId);

	public List<Aircraft> deleteAircraft(int aircraftId);

	public List<Aircraft> createAircraft(Aircraft aircraft);

	public List<Aircraft> updateAircraft(Aircraft aircraft);
public List<Aircraft> findByCrusingRange(double crusingRange);
	
	public List<Aircraft> findByCrusingRangeAndAircraftId(
			double crusingrange,int aircraftId);
	
	public List<Aircraft> findAlldetails(
			double maxcrusingrange,
			double crusingrange
			);

}
