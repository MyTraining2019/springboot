package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Aircraft;
import org.cap.demo.service.IAircraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class AircraftController {

	@Autowired
	private IAircraftService aircraftService;
	
	@GetMapping("/aircrafts")
	public ResponseEntity<List<Aircraft>> getAll(){
		List<Aircraft> aircrafts= aircraftService.getAllAircrafts();
		if(aircrafts.isEmpty() || aircrafts==null) {
			return new ResponseEntity("Sorry! Aircraft not Available!" ,
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
		
	}
	
	
	@GetMapping("/aircrafts/{aircraftId}")
	public ResponseEntity<Aircraft> findAircraft(
			@PathVariable("aircraftId")int aircraftId){
		Aircraft aircrafts= aircraftService.findAircraft(aircraftId);
		if( aircrafts==null) {
			return new ResponseEntity("Sorry! Aircraft id not Available!" ,
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Aircraft>(aircrafts, HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/aircrafts/{aircraftId}")
	public ResponseEntity<List<Aircraft>> deleteAircraft(
			@PathVariable("aircraftId")int aircraftId){
		List<Aircraft> aircrafts= aircraftService.deleteAircraft(aircraftId);
		if(aircrafts.isEmpty() || aircrafts==null) {
			return new ResponseEntity("Sorry! Aircraft Id does not exists!!" ,
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
	
	}
	
	
	
	@PostMapping("/aircrafts")
	public ResponseEntity<List<Aircraft>> createAircraft(
			@RequestBody Aircraft aircraft){
		List<Aircraft> aircrafts= aircraftService.createAircraft(aircraft);
		if(aircrafts.isEmpty() || aircrafts==null) {
			return new ResponseEntity("Sorry! Aircraft Id does not exists!!" ,
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
	
	}
	
	
}
