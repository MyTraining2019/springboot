package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Aircraft;

public interface IAircraftDao {
	
	public List<Aircraft> getAllAircrafts();

	public Aircraft findAircraft(int aircraftId);

	public List<Aircraft> deleteAircraft(int aircraftId);

	public List<Aircraft> createAircraft(Aircraft aircraft);

}
