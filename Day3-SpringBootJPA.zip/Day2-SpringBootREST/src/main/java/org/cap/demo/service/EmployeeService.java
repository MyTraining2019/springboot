package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Employee;

public interface EmployeeService {
	
	public List<Employee> getAllEmployees();
	
	public Employee findEmployee(Long employeeId);
	public List<Employee> deleteEmployee(Long employeeId);
	public List<Employee> createEmployee(Employee employee);
	public List<Employee> updateEmployee(Employee employee,Long empId);
}
