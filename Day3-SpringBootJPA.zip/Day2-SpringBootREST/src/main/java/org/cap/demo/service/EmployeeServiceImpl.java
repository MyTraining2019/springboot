package org.cap.demo.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.cap.demo.model.Employee;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeServiceImpl implements EmployeeService{
	
	private static final AtomicLong id=new AtomicLong(1);
	
	private static List<Employee> employees;
	
	static {
		employees=dummyEmployeeList();
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return employees;
	}

	
	
	
	private static List<Employee> dummyEmployeeList(){
		List<Employee> employees=new ArrayList<>();
		
		employees.add(new Employee(id.incrementAndGet(), "Tom", "Jerry", 23000));
		employees.add(new Employee(id.incrementAndGet(), "Sam", "Jack", 13000));
		employees.add(new Employee(id.incrementAndGet(), "Kamal", "Thomson", 25000));
		return employees;
	}




	@Override
	public Employee findEmployee(Long employeeId) {
		
		for(Employee emp:employees)
		{
			if(emp.getEmpid()==employeeId)
				return emp;
		}
		
		return null;
	}




	@Override
	public List<Employee> deleteEmployee(Long employeeId) {
		Employee emp=findEmployee(employeeId);
		
		employees.remove(emp);
		
		return employees;
	}




	@Override
	public List<Employee> createEmployee(Employee employee) {
		employees.add(employee);
		return employees;
	}




	@Override
	public List<Employee> updateEmployee(Employee employee, Long empId) {
		
		Iterator<Employee> it=employees.iterator();
		while(it.hasNext()) {
			Employee employee2=it.next();
			if(employee2.getEmpid()==empId) {
				employee2.setFirstName(employee.getFirstName());
				employee2.setLastName(employee.getLastName());
				employee2.setSalary(employee.getSalary());
			}
		}
		
		return employees;
	}
}
