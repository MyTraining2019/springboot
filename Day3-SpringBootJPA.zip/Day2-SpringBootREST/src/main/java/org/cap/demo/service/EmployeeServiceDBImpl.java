package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.EmployeeDao;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeService")
public class EmployeeServiceDBImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeDao.findAll();
	}

	@Override
	public Employee findEmployee(Long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> deleteEmployee(Long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> createEmployee(Employee employee) {
	
		 employeeDao.save(employee);
		 return employeeDao.findAll();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee, Long empId) {
		// TODO Auto-generated method stub
		return null;
	}

}
