/**
 * 
 */

function validate(){
	var userName=form1.username.value;
	
	if(userName=="" || userName==null || userName==" "){
		document.getElementById("userErrMsg").innerHTML="* Please enter userName";
			return false;
	}
	return true;
	
}