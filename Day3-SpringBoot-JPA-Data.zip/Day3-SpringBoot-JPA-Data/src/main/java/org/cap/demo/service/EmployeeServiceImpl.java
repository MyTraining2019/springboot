package org.cap.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.dao.EmployeeDao;
import org.cap.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao empDao;
	
	private static AtomicInteger empId=new AtomicInteger(0);
	private static List<Employee> employees;
	
	static {
		employees=dummyEmployeeList();
	}

	
	private static List<Employee> dummyEmployeeList() {
		
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(empId.getAndIncrement(), "Tom", "Jerry", 12000));
		employees.add(new Employee(empId.getAndIncrement(), "Jack", "Jercy", 20001));
		employees.add(new Employee(empId.getAndIncrement(), "Emi", "Jerry", 34000));
		employees.add(new Employee(empId.getAndIncrement(), "Kine", "Thomson", 78000));
		employees.add(new Employee(empId.getAndIncrement(), "larry", "Jack", 45000));
		employees.add(new Employee(empId.getAndIncrement(), "John", "Abraham", 33000));
		return employees;
	}
	
	
	public void saveAll() {
		
		for(Employee employee:employees)
			empDao.save(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		//saveAll();
		return empDao.findAll();
	}


	@Override
	public Employee findEmployee(int employeeId) {
		
		return empDao.findOne(employeeId);
	}


	@Override
	public List<Employee> deleteEmployee(int employeeId) {
		empDao.delete(employeeId);
		return empDao.findAll();
	}


	@Override
	public List<Employee> createEmployee(Employee employee) {
		empDao.save(employee);
		return empDao.findAll();
	}


	@Override
	public List<Employee> updateEmployee(Employee employee) {
		
		Employee emp=empDao.findOne(employee.getEmpId());
		if(emp!=null)
			empDao.save(employee);
		
		return empDao.findAll();
	}


	@Override
	public List<Employee> findByFirstName(String firstName) {
		
		return empDao.findByFirstName(firstName);
	}


	@Override
	public List<Employee> findByFirstNameOrLastName(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return empDao.findByFirstNameOrLastName(firstName, lastName);
	}


	@Override
	public List<Employee> filterBySalary(double salary) {
		
		return empDao.filterBySalary(salary);
	}

}
