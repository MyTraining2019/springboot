package org.cap.demo.restcontroller;

import java.util.List;

import org.cap.demo.pojo.Product;
import org.cap.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	private ProductService product_Service;

	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		List<Product> products=product_Service.getAllProducts();
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product list not available",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProduct(@PathVariable("productId") Integer productId){
		
		Product product=product_Service.searchProduct(productId);
		
		if(product==null) {
			return new ResponseEntity("Sorry! Product Id not Found",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(@PathVariable("productId")
				Integer productId){
		
		List<Product> products=product_Service.deleteProduct(productId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not Found",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(@RequestBody Product product){
		
		List<Product> products=	product_Service.createProduct(product);
		if(products.isEmpty() || products==null)
			return new ResponseEntity("Product creation Error!",
					HttpStatus.CONFLICT);
		
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	}
	
	
	@PutMapping("/products/{productId}")
	public ResponseEntity<List<Product>> updateProduct(@RequestBody Product product,
			@PathVariable("productId") Integer productId){
		
		List<Product> products=	product_Service.createProduct(product);
		if(products.isEmpty() || products==null)
			return new ResponseEntity("Product creation Error!",
					HttpStatus.CONFLICT);
		
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	}
	
	
	
}
