package org.cap.demo.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Product;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service("product_Service")
public class ProductServiceImpl implements ProductService{
	
	private static AtomicInteger productId=new AtomicInteger(0);
	private static List<Product> products;
	
	static {
		products=dummyProductList();
	}

	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}

	
	private static List<Product> dummyProductList(){
		List<Product> products=new ArrayList<>();
		
		products.add(new Product(productId.incrementAndGet(), "ToothPaste", 12.34, 3.5, 10));
		products.add(new Product(productId.incrementAndGet(), "Lux", 56, 3.5, 10));
		products.add(new Product(productId.incrementAndGet(), "Hamam",60, 4.5, 7));
		products.add(new Product(productId.incrementAndGet(), "Medimix", 23, 3.5, 3));
		products.add(new Product(productId.incrementAndGet(), "Lifebuoy", 22, 2.5, 110));
		products.add(new Product(productId.incrementAndGet(), "Cintal", 33, 4.5, 1));
		products.add(new Product(productId.incrementAndGet(), "Sandal",89, 3.5, 100));
		
		return products;
	}


	@Override
	public Product searchProduct(int productId) {
		for(Product product:products)
		{
			if(product.getProductId()==productId)
				return product;
		}
		return null;
	}


	@Override
	public List<Product> deleteProduct(int productId) {
		boolean flag=false;
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext())
		{
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				iterator.remove();
				flag=true;
			}
		}
		if(flag)
			return products;
		else
			return null;
	}


	@Override
	public List<Product> createProduct(Product product) {
		products.add(product);
		return products;
	}
	
	
	
	
	
	
	
	
	
	
}
