package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2SpringMvcRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2SpringMvcRestApplication.class, args);
	}
}
