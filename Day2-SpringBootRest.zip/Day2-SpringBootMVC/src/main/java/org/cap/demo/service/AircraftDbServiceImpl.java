package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAircraftDao;
import org.cap.demo.dao.IAircraftDbDao;
import org.cap.demo.model.Aircraft;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("aircraftDbService")
public class AircraftDbServiceImpl implements IAircraftService {
	
	@Autowired
	private IAircraftDbDao aircraftDbDao;
	
	@Autowired
	private IAircraftDao aircraftDao;

	
	public List<Aircraft> addAll(){
		List<Aircraft> aircrafts= aircraftDao.getAllAircrafts();
		
		/*for(Aircraft aircraft:aircrafts) {
			aircraftDbDao.save(aircraft);
		}*/
		
		aircraftDbDao.save(aircrafts);
		
		return aircraftDbDao.findAll();
	}


	@Override
	public List<Aircraft> getAllAircrafts() {
		
		return aircraftDbDao.findAll();
	}

	@Override
	public Aircraft findAircraft(int aircraftId) {
		
		return aircraftDbDao.findOne(aircraftId);
	}

	@Override
	public List<Aircraft> deleteAircraft(Integer aircraftId) {
		aircraftDbDao.delete(aircraftId);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> createAircraft(Aircraft aircraft) {
		aircraftDbDao.save(aircraft);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> updateAircraft(Aircraft aircraft) {
		aircraftDbDao.save(aircraft);
		return aircraftDbDao.findAll();
	}


	@Override
	public List<Aircraft> findByAircraftIdOrAircraftName(int aircraftId, String aircraftName) {
		
		return aircraftDbDao.findByAircraftIdOrAircraftName(aircraftId, aircraftName);
	}


	@Override
	public List<Aircraft> priceSearch(double price) {
		
		return aircraftDbDao.priceSearch(price);
	}

}
