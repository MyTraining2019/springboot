package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.model.Aircraft;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("aircraftDbDao")
@Transactional
public interface IAircraftDbDao extends JpaRepository<Aircraft, Integer>{
	
	public List<Aircraft> findByAircraftIdOrAircraftName(int aircraftId,String aircraftName);


	//JPQL Query
	//@Query("select aircraft from Aircraft aircraft where aircraft.price>=?") //positional 
	@Query("select aircraft from Aircraft aircraft where aircraft.price>=:AircraftPrice") //Named Parameter
	public List<Aircraft> priceSearch(@Param("AircraftPrice") double price);
}
