package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Aircraft;
import org.cap.demo.service.IAircraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1")
public class AircraftController {

	@Autowired
	private IAircraftService aicraftService;
	
	@GetMapping("/aircrafts")
	public ResponseEntity<List<Aircraft>> getAllAircrafts() {
		
		List<Aircraft> aircrafts=aicraftService.getAllAircrafts();
		
		if(aircrafts.isEmpty() || aircrafts==null)
			return new ResponseEntity("Sorry! Details Not Available Now!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
		
	}
	
	
	
	@GetMapping("/aircrafts/{aircraftId}")
	public ResponseEntity<Aircraft> findAircraft(@PathVariable("aircraftId") Integer aircraftId) {
		
		Aircraft aircraft=aicraftService.findAircraft(aircraftId);
		
		if(aircraft==null) {
			return new ResponseEntity("Sorry! AircraftID does Not exists!", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Aircraft>(aircraft, HttpStatus.OK);
	}
	
	
	
	
	
	@DeleteMapping("/aircrafts/{aircraftId}")
	public ResponseEntity<List<Aircraft>> deleteAircraft(@PathVariable("aircraftId") Integer aircraftId) {
		
		List<Aircraft> aircraft=aicraftService.deleteAircraft(aircraftId);
		
		if(aircraft==null || aircraft.isEmpty()) {
			return new ResponseEntity("Sorry! Aircraft details not available!", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircraft>>(aircraft, HttpStatus.OK);
	}
	
	
		@PostMapping("/aircrafts")
		public ResponseEntity<List<Aircraft>> createAircraft(@RequestBody Aircraft aircraft){
			
			List<Aircraft> aircrafts= aicraftService.createAircraft(aircraft);
			
			
			if(aircrafts==null || aircrafts.isEmpty()) {
				return new ResponseEntity("Error in Aircraft insertion !", HttpStatus.NOT_FOUND);
			}
			
			
			return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
		}
		
		
		@PutMapping("/aircrafts")
		public ResponseEntity<List<Aircraft>> updateAircraft(@RequestBody Aircraft aircraft){
			
			List<Aircraft> aircrafts= aicraftService.updateAircraft(aircraft);
			
			
			if(aircrafts==null || aircrafts.isEmpty()) {
				return new ResponseEntity("Error in Aircraft Updation !", HttpStatus.NOT_FOUND);
			}
			
			
			return new ResponseEntity<List<Aircraft>>(aircrafts, HttpStatus.OK);
		}
		
		
	}
	
	
	
	