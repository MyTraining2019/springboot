package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Aircraft;

public interface IAircraftService {
	
	public List<Aircraft> getAllAircrafts();
	public Aircraft findAircraft(int aircraftId);
	public List<Aircraft> deleteAircraft(Integer aircraftId);
	public List<Aircraft> createAircraft(Aircraft aircraft);
	public List<Aircraft> updateAircraft(Aircraft aircraft);
	public List<Aircraft> addAll();
	
	
	public List<Aircraft> findByAircraftIdOrAircraftName(int aircraftId,String aircraftName);
	public List<Aircraft> priceSearch(double price);
}
