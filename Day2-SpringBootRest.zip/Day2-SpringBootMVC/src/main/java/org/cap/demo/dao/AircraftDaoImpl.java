package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Aircraft;
import org.springframework.stereotype.Repository;

@Repository("aircraftDao")
public class AircraftDaoImpl implements IAircraftDao {
	private static AtomicInteger aircraftId=new AtomicInteger(1000);
	
	private static List<Aircraft> aircrafts=dummyDbAircraft();
	
	private static List<Aircraft> dummyDbAircraft(){
		List<Aircraft> aircrafts=new ArrayList<>();
		
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "6E-340", "Indigo 6E", 12000, 4500000, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "JET-8900", "JET-Airways", 12000, 4500000, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "6E-111", "Indigo 6E", 4500, 12455, new Date(2001-1900,3,21)));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "JET-3410", "JET-Airways", 1200, 78768768, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "JET-191", "JET-Airways", 3333, 345435, new Date(1991-1900,2,12)));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "SPICE-121", "Spice JET", 1244, 345435, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "SPICE-131", "Spice JET", 8900, 8779879, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "6E-777", "Indigo 6E", 12000, 56765757, new Date(1987-1900,7,11)));
		
		return aircrafts;
	}
	

	@Override
	public List<Aircraft> getAllAircrafts() {
		
		return aircrafts;
	}


	@Override
	public Aircraft findAircraft(int aircraftId) {
		
		for(Aircraft aircraft:aircrafts) {
			if(aircraft.getAircraftId()==aircraftId) {
				return aircraft;
			}
		}
		
		return null;
	}


	@Override
	public List<Aircraft> deleteAircraft(Integer aircraftId) {
		
		boolean flag=false;
		
		Iterator<Aircraft> iterator= aircrafts.iterator();
		while(iterator.hasNext()) {
			Aircraft aircraft= iterator.next();
			if(aircraft.getAircraftId() == aircraftId) {
				flag=true;
				iterator.remove();
				break;
			}
			
		}
		if(flag) {
			return aircrafts;
		}else {
			return null;
		}
		
	}


	@Override
	public List<Aircraft> createAircraft(Aircraft aircraft) {
		
		aircrafts.add(aircraft);
		
		return aircrafts;
	}

}
