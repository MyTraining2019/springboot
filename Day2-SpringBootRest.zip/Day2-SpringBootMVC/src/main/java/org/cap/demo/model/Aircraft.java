package org.cap.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Aircraft {
	
	@Id
	private int aircraftId;
	private String aircraftName;
	private String aircraftAbbrevation;
	private double crusingRange;
	private double price;
	
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date launchDate;
	
	public Aircraft() {
		
	}
	
	public Aircraft(int aircraftId, String aircraftName, String aircraftAbbrevation, double crusingRange, double price,
			Date launchDate) {
		super();
		this.aircraftId = aircraftId;
		this.aircraftName = aircraftName;
		this.aircraftAbbrevation = aircraftAbbrevation;
		this.crusingRange = crusingRange;
		this.price = price;
		this.launchDate = launchDate;
	}
	public int getAircraftId() {
		return aircraftId;
	}
	public void setAircraftId(int aircraftId) {
		this.aircraftId = aircraftId;
	}
	public String getAircraftName() {
		return aircraftName;
	}
	public void setAircraftName(String aircraftName) {
		this.aircraftName = aircraftName;
	}
	public String getAircraftAbbrevation() {
		return aircraftAbbrevation;
	}
	public void setAircraftAbbrevation(String aircraftAbbrevation) {
		this.aircraftAbbrevation = aircraftAbbrevation;
	}
	public double getCrusingRange() {
		return crusingRange;
	}
	public void setCrusingRange(double crusingRange) {
		this.crusingRange = crusingRange;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getLaunchDate() {
		return launchDate;
	}
	public void setLaunchDate(Date launchDate) {
		this.launchDate = launchDate;
	}
	@Override
	public String toString() {
		return "Aircraft [aircraftId=" + aircraftId + ", aircraftName=" + aircraftName + ", aircraftAbbrevation="
				+ aircraftAbbrevation + ", crusingRange=" + crusingRange + ", price=" + price + ", launchDate="
				+ launchDate + "]";
	}
	
	
	
	
}
