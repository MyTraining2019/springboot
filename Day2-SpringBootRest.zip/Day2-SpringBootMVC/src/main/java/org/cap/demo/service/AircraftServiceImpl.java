package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAircraftDao;
import org.cap.demo.model.Aircraft;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("aicraftService")
public abstract class AircraftServiceImpl implements IAircraftService{

	@Autowired
	private IAircraftDao aircraftDao;
	
	@Override
	public List<Aircraft> getAllAircrafts() {
		
		return aircraftDao.getAllAircrafts();
	}

	@Override
	public Aircraft findAircraft(int aircraftId) {
		
		return aircraftDao.findAircraft(aircraftId);
	}

	@Override
	public List<Aircraft> deleteAircraft(Integer aircraftId) {
		
		return aircraftDao.deleteAircraft(aircraftId);
	}

	@Override
	public List<Aircraft> createAircraft(Aircraft aircraft) {
	
		return aircraftDao.createAircraft(aircraft);
	}

	@Override
	public List<Aircraft> updateAircraft(Aircraft aircraft) {
		
		return aircraftDao.updateAircraft(aircraft);
	}

}
