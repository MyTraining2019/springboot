package org.cap.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.dao.IEmployeeDAODB;
import org.cap.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeServiceDB")
@Transactional
public class EmployeeServiceDBImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeDAODB employeeDaoDB;

	@Override
	public List<Employee> getAllEmployee() {
		
		return employeeDaoDB.findAll();
	}

	@Override
	public Employee findEmployee(Integer empId) {
		
		return employeeDaoDB.findOne(empId);
	}

	@Override
	public List<Employee> deleteEmployee(Integer empId) {
		employeeDaoDB.delete(empId);
		return employeeDaoDB.findAll();
	}

	@Override
	public List<Employee> createemployee(Employee employee) {
		employeeDaoDB.save(employee);
		return employeeDaoDB.findAll();
	}

	@Override
	public List<Employee> updateemployee(Employee employee) {
		employeeDaoDB.save(employee);
		return employeeDaoDB.findAll();
	}

}
