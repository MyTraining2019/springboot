package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeDao empDao;

	@Override
	public List<Employee> getAllEmployee() {
		
	return empDao.getAllEmployee();
	}

	@Override
	public Employee findEmployee(Integer empId) {
		// TODO Auto-generated method stub
		return empDao.findEmployee(empId);
	}

	@Override
	public List<Employee> deleteEmployee(Integer empId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmployee(empId);
	}

	@Override
	public List<Employee> createemployee(Employee employee) {
		// TODO Auto-generated method stub
		return empDao.createemployee(employee);
	}

	@Override
	public List<Employee> updateemployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

}
