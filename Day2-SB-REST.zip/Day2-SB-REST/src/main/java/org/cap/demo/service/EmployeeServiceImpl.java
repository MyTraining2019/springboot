package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeDao empDao;

	@Override
	public List<Employee> getAllEmployee() {
		
	return empDao.getAllEmployee();
	}

}
