package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Employee;
import org.springframework.stereotype.Repository;

@Repository("empDao")
public class EmployeeDaoImpl implements IEmployeeDao{
	private static AtomicInteger employeeId=new AtomicInteger(0);
	
	private static List<Employee> employees=getDummyEmployees();
	
	private static List<Employee> getDummyEmployees(){
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(employeeId.incrementAndGet(), "tom", "Jerry", 344354, 23));
		employees.add(new Employee(employeeId.incrementAndGet(), "Tim", "Lee", 34000, 34));
		employees.add(new Employee(employeeId.incrementAndGet(), "Jack", "Thomson", 34120, 26));
		employees.add(new Employee(employeeId.incrementAndGet(), "Emi", "Jack", 6700, 34));
		employees.add(new Employee(employeeId.incrementAndGet(), "Jessy", "Rao", 78000, 56));
		
		return employees;
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return employees;
	}

}
