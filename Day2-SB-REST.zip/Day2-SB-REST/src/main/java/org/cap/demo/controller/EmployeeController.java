package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.pojo.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
	
	@Autowired
	private IEmployeeService empService;

	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> employees= empService.getAllEmployee();
		
		if(employees.isEmpty()|| employees==null) {
			return new ResponseEntity("Sorry! Employee Details Not Loaded.",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
	

	@GetMapping("/employees/{empId}")
	public ResponseEntity<Employee> findEmployee(@PathVariable("empId") Integer empId){
		Employee employee= empService.findEmployee(empId);
		
		if( employee==null) {
			return new ResponseEntity("Sorry! Employee Id  Not Found!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@DeleteMapping("/employees/{empId}")
	public ResponseEntity<List<Employee>> deleteEmployee(@PathVariable("empId") Integer empId){
		List<Employee> employee= empService.deleteEmployee(empId);
		
		if( employee==null) {
			return new ResponseEntity("Sorry! Employee Id  Not Found!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employee,HttpStatus.OK);
	}
	
	
	
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(@RequestBody Employee employee){
		
		
		List<Employee> employees=empService.createemployee(employee);
		
		if(employees.isEmpty()|| employees==null) {
			return new ResponseEntity("Sorry! Employee Details Not Loaded.",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
	
	
	
	
}

















