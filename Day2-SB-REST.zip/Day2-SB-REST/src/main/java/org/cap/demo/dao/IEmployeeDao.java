package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.pojo.Employee;

public interface IEmployeeDao {
	public List<Employee> getAllEmployee();
}
