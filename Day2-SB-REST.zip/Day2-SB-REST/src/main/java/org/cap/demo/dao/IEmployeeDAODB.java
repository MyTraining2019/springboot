package org.cap.demo.dao;

import org.cap.demo.pojo.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("employeeDaoDB")
public interface IEmployeeDAODB extends JpaRepository<Employee, Integer>{

}
