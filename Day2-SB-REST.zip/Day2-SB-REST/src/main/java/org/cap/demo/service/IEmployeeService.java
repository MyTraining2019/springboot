package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Employee;

public interface IEmployeeService {

	
	public List<Employee> getAllEmployee();

	public Employee findEmployee(Integer empId);

	public List<Employee> deleteEmployee(Integer empId);
	
	public List<Employee> createemployee(Employee employee);
	
	public List<Employee> updateemployee(Employee employee);
}
