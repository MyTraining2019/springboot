package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Employee;

public interface IEmployeeService {

	
	public List<Employee> getAllEmployee();
}
