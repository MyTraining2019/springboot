package org.cap.demo.controller;

import org.cap.demo.pojo.Login;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		return new ModelAndView("helloPage", "msg", "Hey! Good AfterNoon!");
	}
	
	@RequestMapping("/login")
	public ModelAndView loginPage() {
		return  new ModelAndView("login","login",new Login());
	}
	
	@RequestMapping(value="validateUser",method=RequestMethod.POST)
	public String validateUser(@ModelAttribute("login") Login login) {
		if(login.getUserName().equalsIgnoreCase("tom") && 
				login.getUserPwd().equals("tom123"))
			return "success";
		return "login";
	}
}












