package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Order;
import org.cap.demo.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class OrderController {
	
	@Autowired
	private IOrderService orderService;

	@GetMapping("/orders")
	public ResponseEntity<List<Order>> getAllOrders(){
		
		List<Order> orders= orderService.getAllOrders();
		
		if(orders.isEmpty() || orders==null) {
			return new ResponseEntity("Sorry! No orders availble!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}
	
	@GetMapping("/orders/{orderId}")
	public ResponseEntity<Order> findOrder(@PathVariable("orderId") int orderId)
	{
		Order order= orderService.findOrder(orderId);
		if(order==null) {
			return new ResponseEntity("Sorry! Order Id does not exists!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Order>(order, HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/orders/{orderId}")
	public ResponseEntity<List<Order>> deleteOrder(@PathVariable("orderId") 
	Integer orderId){
		
	List<Order> orders= orderService.deleteOrder(orderId);
		
		if(orders.isEmpty() || orders==null) {
			return new ResponseEntity("Sorry! Order Id does not exists!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);

			
	}
	
	@PostMapping("/orders")
	public ResponseEntity<List<Order>> createOrder(
			@RequestBody Order order){
		
		List<Order> orders= orderService.createOrder(order);
	
		if(orders.isEmpty() || orders==null) {
			return new ResponseEntity("Sorry! Insertion Failed",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
}
