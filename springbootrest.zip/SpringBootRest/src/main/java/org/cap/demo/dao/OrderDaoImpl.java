package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Order;
import org.springframework.stereotype.Repository;

@Repository("orderDao")
public class OrderDaoImpl implements IOrderDao{
	
	private static AtomicInteger orderNo=new AtomicInteger(1000);
	private static List<Order> orders=dummyDb();

	
	private static List<Order> dummyDb(){
		List<Order> orders=new ArrayList<>();
		orders.add(new Order(orderNo.incrementAndGet(), new Date(), "Sony TV", 3, 230000.56));
		orders.add(new Order(orderNo.incrementAndGet(), new Date(2001-1900,3,23), "Samsumy Mobile", 13, 29003.56));
		orders.add(new Order(orderNo.incrementAndGet(), new Date(2001-1900,1,21), "Apple iphone", 1, 45123.56));
		orders.add(new Order(orderNo.incrementAndGet(), new Date(2005-1900,3,23), "Apple Ipod", 13, 4565767.56));
		orders.add(new Order(orderNo.incrementAndGet(), new Date(2008-1900,7,12), "Iphone", 63, 121905.56));
		
		return orders;
	}
	
	
	@Override
	public List<Order> getAllOrders() {
		
		return orders;
	}


	@Override
	public Order findOrder(int orderId) {

		for(Order order:orders) {
			if(orderId==order.getOrderId()) {
				return order;
			}
		}
		
		return null;
	}


	@Override
	public List<Order> deleteOrder(Integer orderId) {
		
		boolean flag=false;
		
		Iterator<Order> iterator= orders.iterator();
		while(iterator.hasNext()) {
			Order order=iterator.next();
			if(order.getOrderId()==orderId) {
				flag=true;
				iterator.remove();
				break;
			}
			
		}
		if(flag)
			return orders;
		else
			return null;
	}


	@Override
	public List<Order> createOrder(Order order) {
		orders.add(order);
		return orders;
	}

}
