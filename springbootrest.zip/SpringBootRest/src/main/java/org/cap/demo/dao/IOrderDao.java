package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Order;

public interface IOrderDao {
	
	public List<Order> getAllOrders();
	
	public Order findOrder(int orderId);

	public List<Order> deleteOrder(Integer orderId);

	public List<Order> createOrder(Order order);

}
