package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IOrderDao;
import org.cap.demo.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderServiceImpl  implements IOrderService{

	@Autowired
	private IOrderDao orderDao;
	
	@Override
	public List<Order> getAllOrders() {
		
		return orderDao.getAllOrders();
	}

	@Override
	public Order findOrder(int orderId) {
		// TODO Auto-generated method stub
		return orderDao.findOrder(orderId);
	}

	@Override
	public List<Order> deleteOrder(Integer orderId) {
		// TODO Auto-generated method stub
		return orderDao.deleteOrder(orderId);
	}

	@Override
	public List<Order> createOrder(Order order) {
		// TODO Auto-generated method stub
		return orderDao.createOrder(order);
	}

}
