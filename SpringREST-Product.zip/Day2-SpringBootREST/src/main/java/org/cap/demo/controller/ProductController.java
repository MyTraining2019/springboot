package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.pojo.Product;
import org.cap.demo.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	private IProductService prodService;
	
	/*@GetMapping("/hello")
	public ResponseEntity<String> sayHello() {
		//String str="Hello";
		String str=null;
		if(str==null) {
			return new ResponseEntity("Sorry! Data Not Available",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}*/
	
	
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products= prodService.getAllProducts();
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product not available", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	

	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProducts
				(@PathVariable("productId")Integer prodId){
		
		Product products= prodService.findProducts(prodId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not found.", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(products, HttpStatus.OK);
	}
	
	
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProducts
				(@PathVariable("productId")Integer prodId){
		
		List<Product> products= prodService.deleteProducts(prodId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not found.", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>> (products, HttpStatus.OK);
	}
	
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProducts(
			@RequestBody Product product){
		
		List<Product> products=prodService.createProduct(product);
		
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry! Product insertion error.", HttpStatus.CONFLICT);
		}
		
		return new ResponseEntity<List<Product>> (products, HttpStatus.OK);
	}
	
	

	
	@PutMapping("/products")
	public ResponseEntity<List<Product>> updateProducts(
			@RequestBody Product product){
		
		List<Product> products=prodService.updateProduct(product);
		
		return new ResponseEntity<List<Product>> (products, HttpStatus.OK);
		
	}
	
}
