function validate(){
	
	var flag=false;
	var userName=f1.uname.value;
	var userPwd=f1.upwd.value;
	//alert(userName);
	
	if(userName=="" || userName==null){
		document.getElementById('userErrMsg').innerHTML="* Please enter userName.";
		flag=false;
	}else if(userPwd=="" || userPwd==null){
		document.getElementById('userErrMsg').innerHTML=" ";
		document.getElementById('pwdErrMsg').innerHTML="* Please enter userPassword.";
		flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}