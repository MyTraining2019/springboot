package org.cap.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@RequestMapping("/validateLogin")
	public ModelAndView validateLogin(@RequestParam("uname") String userName,
			@RequestParam("upwd") String userPwd) {
		
	
		if(userName.equalsIgnoreCase("tom") && 
				userPwd.equalsIgnoreCase("tom123")) {
			//return "success";
			return new ModelAndView("success", "user", userName);
		}
		
		return new ModelAndView("redirect:/");
	}

}
