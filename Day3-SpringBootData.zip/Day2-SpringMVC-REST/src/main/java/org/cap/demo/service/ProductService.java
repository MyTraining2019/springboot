package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Product;

public interface ProductService {
	
	public List<Product> getAllProducts();
	
	public Product searchProduct(int productId);
	
	public List<Product> deleteProduct(int productId);
	
	public List<Product> createProduct(Product product);
	
	public List<Product> findByProductName(String productName);
	
	public List<Product> findByProductNameOrQuantity(String productName,int quantity);
	
	
	public List<Product> findByProduct(int quantity);

}
