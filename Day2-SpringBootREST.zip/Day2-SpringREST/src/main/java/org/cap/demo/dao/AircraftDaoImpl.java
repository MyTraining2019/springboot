package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Aircrafts;
import org.springframework.stereotype.Repository;

@Repository("aircraftDao")
public class AircraftDaoImpl implements AircraftDao{
	
	private static AtomicInteger aircraftId=new AtomicInteger(1000);
	private static List<Aircrafts> aircrafts=dummyDBAircrafts();
	
	
	private static List<Aircrafts> dummyDBAircrafts(){
		List<Aircrafts> aircrafts=new ArrayList<>();
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "6E-31980", "Indigo 6E", 23000));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "SPI-234", "SPICEJET ", 45000));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "JET-34576", "JetAirways", 12000));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "6E-345", "Indigo 6E", 5000));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "6E-901", "Indigo 6E", 7000));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "SPI-31980", "SPICEJET", 12345));
		aircrafts.add(new Aircrafts(aircraftId.incrementAndGet(), "JET-10001", "JetAirways", 562));
		
		
		return aircrafts;
	}

	@Override
	public List<Aircrafts> getAllAircrafts() {
		
		return aircrafts;
	}

	@Override
	public Aircrafts findAircraft(Integer aircraftId) {
	for(Aircrafts aircraft:aircrafts) {
		if(aircraft.getAircraftId()==aircraftId)
			return aircraft;
	}
		
		return null;
	}

	@Override
	public List<Aircrafts> deleteAircrafts(Integer aircraftId) {
		
		
		Iterator<Aircrafts> iterator= aircrafts.iterator();
		
		while(iterator.hasNext()) {
			Aircrafts aircrafts= iterator.next();
			if(aircrafts.getAircraftId()==aircraftId) {
				iterator.remove();
				break;
			}
		}
		return aircrafts;
	}

	@Override
	public List<Aircrafts> createAircrafts(Aircrafts aircraft) {
		aircrafts.add(aircraft);
		return aircrafts;
	}

	
}
