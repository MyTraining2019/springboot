package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.AircraftDao;
import org.cap.demo.model.Aircrafts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("aircraftService")
public class AircraftServiceImpl implements AircraftService{

	@Autowired
	private AircraftDao aircraftDao;
	
	@Override
	public List<Aircrafts> getAllAircrafts() {
		
		return aircraftDao.getAllAircrafts();
	}

	@Override
	public Aircrafts findAircraft(Integer aircraftId) {
		// TODO Auto-generated method stub
		return aircraftDao.findAircraft(aircraftId);
	}

	@Override
	public List<Aircrafts> deleteAircrafts(Integer aircraftId) {
		// TODO Auto-generated method stub
		return aircraftDao.deleteAircrafts(aircraftId);
	}

	@Override
	public List<Aircrafts> createAircrafts(Aircrafts aircraft) {
		// TODO Auto-generated method stub
		return aircraftDao.createAircrafts(aircraft);
	}

}
