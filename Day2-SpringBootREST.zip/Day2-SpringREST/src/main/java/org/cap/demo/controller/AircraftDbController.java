package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Aircrafts;
import org.cap.demo.service.AircraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api/v2")
@RestController
public class AircraftDbController {
	@Autowired
	private AircraftService aircraftDbService;
	
	
	
	

	@GetMapping(value="/aircraftRange/{crusingRange}/{aName}")
	public ResponseEntity<List<Aircrafts>> serachAirctaftRangeOrAircraftName(
			@PathVariable("crusingRange")double aircraftRange,
			@PathVariable("aName")String aName) {
	
		List<Aircrafts> aircrafts= aircraftDbService
					.searchCrusingRangeaorName(aName, aircraftRange);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	@GetMapping(value="/aircraftRange/{crusingRange}")
	public ResponseEntity<List<Aircrafts>> serachAirctaftRange(
			@PathVariable("crusingRange")double aircraftRange) {
	
		List<Aircrafts> aircrafts= aircraftDbService.searchCrusingRange(aircraftRange);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	@GetMapping(value="/aircraftName/{aircraftName}")
	public ResponseEntity<List<Aircrafts>> findAirctaftName(
			@PathVariable("aircraftName")String aircraftName) {
	
		List<Aircrafts> aircrafts= aircraftDbService.findByAircraftName(aircraftName);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	//------------------------CRUD OPerations-------------------
	
	@PostMapping(value="/aircrafts")
	public ResponseEntity<List<Aircrafts>> createAirctafts(
			@RequestBody Aircrafts aircraft) {
	
		List<Aircrafts> aircrafts= aircraftDbService.createAircrafts(aircraft);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	@DeleteMapping(value="/aircrafts/{aircraftId}")
	public ResponseEntity<List<Aircrafts>> deleteAirctafts(
			@PathVariable("aircraftId") Integer aircraftId) {
	
		List<Aircrafts> aircrafts= aircraftDbService.deleteAircrafts(aircraftId);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	//@RequestMapping(value="/aircrafts",method=RequestMethod.GET)
	@GetMapping(value="/aircrafts")
	public ResponseEntity<List<Aircrafts>> getAllAirctafts() {
	
		List<Aircrafts> aircrafts= aircraftDbService.getAllAircrafts();
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	@GetMapping(value="/aircrafts/{aircraftId}")
	public ResponseEntity<Aircrafts> findAirctafts(
			@PathVariable("aircraftId") Integer aircraftId) {
	
		Aircrafts aircrafts= aircraftDbService.findAircraft(aircraftId);
		
		if(aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft Id not found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Aircrafts>(aircrafts, HttpStatus.OK);
	}
	
}
