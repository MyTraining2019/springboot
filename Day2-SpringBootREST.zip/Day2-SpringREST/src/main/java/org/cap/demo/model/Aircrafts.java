package org.cap.demo.model;

import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class Aircrafts {
	
	private int aircraftId;
	private String aircraftName;
	private String aircraftAbbreviation;
	private double crusingRange;
	
	public Aircrafts() {
		
	}
	
	public Aircrafts(int aircraftId, String aircraftName, String aircraftAbbreviation, double crusingRange) {
		super();
		this.aircraftId = aircraftId;
		this.aircraftName = aircraftName;
		this.aircraftAbbreviation = aircraftAbbreviation;
		this.crusingRange = crusingRange;
	}
	public int getAircraftId() {
		return aircraftId;
	}
	public void setAircraftId(int aircraftId) {
		this.aircraftId = aircraftId;
	}
	public String getAircraftName() {
		return aircraftName;
	}
	public void setAircraftName(String aircraftName) {
		this.aircraftName = aircraftName;
	}
	public String getAircraftAbbreviation() {
		return aircraftAbbreviation;
	}
	public void setAircraftAbbreviation(String aircraftAbbreviation) {
		this.aircraftAbbreviation = aircraftAbbreviation;
	}
	public double getCrusingRange() {
		return crusingRange;
	}
	public void setCrusingRange(double crusingRange) {
		this.crusingRange = crusingRange;
	}
	@Override
	public String toString() {
		return "Aircrafts [aircraftId=" + aircraftId + ", aircraftName=" + aircraftName + ", aircraftAbbreviation="
				+ aircraftAbbreviation + ", crusingRange=" + crusingRange + "]";
	}
	
	

}
