package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.model.Aircrafts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("aircraftDbDao")
@Transactional
public interface IAircraftDBDao 
	extends JpaRepository<Aircrafts, Integer>{

	
	public List<Aircrafts> findByAircraftName(String aircraftName);
	
	
	@Query("select a from Aircrafts a where a.crusingRange>?")
	public List<Aircrafts> searchCrusingRange(double range);
	
	
	@Query("select a from Aircrafts a where a.crusingRange>:range or "
			+ "a.aircraftName=:aName")
	public List<Aircrafts> searchCrusingRangeaorName(
			@Param("aName")String aName,
			@Param("range")double range);
}
