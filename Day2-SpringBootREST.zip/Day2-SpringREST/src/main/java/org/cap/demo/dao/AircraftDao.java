package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Aircrafts;

public interface AircraftDao {

	
	public List<Aircrafts> getAllAircrafts();

	public Aircrafts findAircraft(Integer aircraftId);

	public List<Aircrafts> deleteAircrafts(Integer aircraftId);

	public List<Aircrafts> createAircrafts(Aircrafts aircraft);
}
