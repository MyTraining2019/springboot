package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAircraftDBDao;
import org.cap.demo.model.Aircrafts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("aircraftDbService")
public class AircraftDbServicceImpl implements AircraftService{

	@Autowired
	private IAircraftDBDao aircraftDbDao;
	
	@Override
	public List<Aircrafts> getAllAircrafts() {
		
		return aircraftDbDao.findAll();
	}

	@Override
	public Aircrafts findAircraft(Integer aircraftId) {
		
		return aircraftDbDao.findOne(aircraftId);
	}

	@Override
	public List<Aircrafts> deleteAircrafts(Integer aircraftId) {
		aircraftDbDao.delete(aircraftId);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircrafts> createAircrafts(Aircrafts aircraft) {
		
		 aircraftDbDao.save(aircraft);
		 
		 return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircrafts> findByAircraftName(String aircraftName) {
		// TODO Auto-generated method stub
		return aircraftDbDao.findByAircraftName(aircraftName);
	}

	@Override
	public List<Aircrafts> searchCrusingRange(double range) {
		// TODO Auto-generated method stub
		return aircraftDbDao.searchCrusingRange(range);
	}

	@Override
	public List<Aircrafts> searchCrusingRangeaorName(String aName, double range) {
		
		return aircraftDbDao.searchCrusingRangeaorName(aName, range);
	}

}
