package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Aircrafts;
import org.cap.demo.service.AircraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/api/v1")
public class AircraftController extends ParentController {

	@Autowired
	private AircraftService aircraftService;
	
	
	@PostMapping(value="/aircrafts")
	public ResponseEntity<List<Aircrafts>> createAirctafts(
			@RequestBody Aircrafts aircraft) {
	
		List<Aircrafts> aircrafts= aircraftService.createAircrafts(aircraft);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	@DeleteMapping(value="/aircrafts/{aircraftId}")
	public ResponseEntity<List<Aircrafts>> deleteAirctafts(
			@PathVariable("aircraftId") Integer aircraftId) {
	
		List<Aircrafts> aircrafts= aircraftService.deleteAircrafts(aircraftId);
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	//@RequestMapping(value="/aircrafts",method=RequestMethod.GET)
	@GetMapping(value="/aircrafts",produces= {"application/json","application/xml"})
	public ResponseEntity<List<Aircrafts>> getAllAirctafts() {
	
		List<Aircrafts> aircrafts= aircraftService.getAllAircrafts();
		
		if(aircrafts.isEmpty() || aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft details not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Aircrafts>>(aircrafts, 
				HttpStatus.OK);
	}
	
	
	
	
	@GetMapping(value="/aircrafts/{aircraftId}")
	public ResponseEntity<Aircrafts> findAirctafts(
			@PathVariable("aircraftId") Integer aircraftId) {
	
		Aircrafts aircrafts= aircraftService.findAircraft(aircraftId);
		
		if(aircrafts==null)
		{
			return new ResponseEntity("Sorry! Aircraft Id not found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Aircrafts>(aircrafts, HttpStatus.OK);
	}
	
}
