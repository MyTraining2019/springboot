package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Aircrafts;

public interface AircraftService {
	public List<Aircrafts> getAllAircrafts();
	public Aircrafts findAircraft(Integer aircraftId);
	public List<Aircrafts> deleteAircrafts(Integer aircraftId);
	public List<Aircrafts> createAircrafts(Aircrafts aircraft);
	
}
