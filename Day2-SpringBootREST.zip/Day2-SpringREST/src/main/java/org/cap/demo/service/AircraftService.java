package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Aircrafts;
import org.springframework.data.repository.query.Param;

public interface AircraftService {
	public List<Aircrafts> getAllAircrafts();
	public Aircrafts findAircraft(Integer aircraftId);
	public List<Aircrafts> deleteAircrafts(Integer aircraftId);
	public List<Aircrafts> createAircrafts(Aircrafts aircraft);
	public List<Aircrafts> findByAircraftName(String aircraftName);
	public List<Aircrafts> searchCrusingRange(double range);
	public List<Aircrafts> searchCrusingRangeaorName(
			String aName,double range);
}
