package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Employee;
import org.cap.demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private EmployeeService empService;
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		
		
		List<Employee> employees=empService.getAllEmployees();
		
		if(employees.isEmpty()) {
			return new ResponseEntity("Employee list not Available", 
					HttpStatus.CONFLICT);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
		
		
	}
}
