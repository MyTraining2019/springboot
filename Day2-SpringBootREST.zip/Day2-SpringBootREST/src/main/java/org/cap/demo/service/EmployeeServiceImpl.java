package org.cap.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.cap.demo.model.Employee;
import org.springframework.stereotype.Service;

@Service("empService")
public class EmployeeServiceImpl implements EmployeeService{
	
	private static final AtomicLong id=new AtomicLong(1);
	
	private static List<Employee> employees;
	
	static {
		employees=dummyEmployeeList();
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return employees;
	}

	
	
	
	private static List<Employee> dummyEmployeeList(){
		List<Employee> employees=new ArrayList<>();
		
		employees.add(new Employee(id.incrementAndGet(), "Tom", "Jerry", 23000));
		employees.add(new Employee(id.incrementAndGet(), "Sam", "Jack", 13000));
		employees.add(new Employee(id.incrementAndGet(), "Kamal", "Thomson", 25000));
		return employees;
	}
}
